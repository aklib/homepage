<?php

namespace Application\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\ServiceManager\ServiceManager;

class IndexController extends AbstractActionController {

    /**
     *
     * @var ServiceManager 
     */
    protected $sm;

    public function indexAction() {
        return new ViewModel();
    }

    
    /**
     * gets ServiceManager
     * @return ServiceManager
     */
    function getServiceManager(): ServiceManager {
        return $this->sm;
    }

    /**
     * Sets ServiceManager
     * @param ServiceManager $serviceManager
     * @return void
     */
    function setServiceManager(ServiceManager $serviceManager): void {
        $this->sm = $serviceManager;
    }

}
