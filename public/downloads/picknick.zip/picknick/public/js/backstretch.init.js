$.backstretch(["https://via.placeholder.com/2000X1333//88929f/5a6270C/O https://placeholder.com/", "https://via.placeholder.com/2000X1333//88929f/5a6270C/O https://placeholder.com/", "https://via.placeholder.com/2000X1333//88929f/5a6270C/O https://placeholder.com/"], {
    duration: 3000,
    fade: 1000,
});