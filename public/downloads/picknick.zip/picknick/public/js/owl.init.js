//*********************/ 
//   Owl Carousel     */
//*********************/ 
$("#clients-testi").owlCarousel({
    margin: 100,
    nav: true,
    autoPlay: 3000,
    items: 4,
    itemsDesktop: [1024, 3],
    itemsDesktopSmall: [900, 2],
    itemsTablet: [600, 1],
});
