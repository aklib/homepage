//Video
$(".player").mb_YTPlayer();